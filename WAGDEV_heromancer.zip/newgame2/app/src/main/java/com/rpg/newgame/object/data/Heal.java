package com.rpg.newgame.object.data;

public class Heal {
    public double HP;
    public double MP;
    public Heal(double HP,double MP){
        this.HP=HP;
        this.MP=MP;
    }
}
