package com.rpg.newgame;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.RequiresApi;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.rpg.newgame.object.Mob;
import com.rpg.newgame.object.Player;

public class BattleHandler {
    //기본리소스
    private Mob[] enemy;
    private  Player[] friendly;
    private ChatUI chatui;
    private BattleWindow window;




    public BattleHandler(LinearLayout chat, ConstraintLayout window, Context con,clickevent c){
        //이곳에서 맵같은걸로 초기화
        //임시제작
        enemy=new Mob[4];
        friendly= new Player[4];
        c.setHandler(this);

        this.chatui=new ChatUI(chat,con,c);
        this.window=new BattleWindow(window,con,4,4,c);

    }

    public void PlayerAttack(int attacker,int target){
        /*플레이어를 공격*/
        friendly[target].Hurt(enemy[attacker].Attack());
    }

    public void MobAttack(int attacker,int target){
        /*몬스터를 공격*/
        enemy[target].Hurt(friendly[attacker].Attack());
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    public void test(Drawable d){
        for (int i=0;i<enemy.length;i++){
            window.test(d,R.id.mob1);
        }
    }













}
