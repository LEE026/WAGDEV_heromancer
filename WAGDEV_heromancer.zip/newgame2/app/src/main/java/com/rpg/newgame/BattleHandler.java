package com.rpg.newgame;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import android.widget.LinearLayout;

import androidx.annotation.RequiresApi;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.rpg.newgame.object.MagicKnight;
import com.rpg.newgame.object.Mob;
import com.rpg.newgame.object.Player;
import com.rpg.newgame.object.Warrior;

public class BattleHandler {
    //기본리소스
    private Mob[] enemy;
    private  Player[] friendly;
    private ChatUI chatui;
    private BattleWindow window;



    private int mobnum=4;
    private int playernum=4;
    public BattleHandler(LinearLayout chat, ConstraintLayout window, Context con,clickevent c){
        //이곳에서 맵같은걸로 초기화
        //임시제작
        enemy=new Mob[mobnum];
        friendly= new Player[playernum];
        for (int i=0;i<playernum;i++){
            enemy[i]= new Warrior();
            friendly[i]=new MagicKnight();
        }

        c.setHandler(this);

        this.chatui=new ChatUI(chat,con,c);
        this.window=new BattleWindow(window,con,playernum,mobnum,c);

    }

    public void PlayerAttack(int attacker,int target){
        /*플레이어를 공격*/
        friendly[target].Hurt(enemy[attacker].Attack());
    }

    public void MobAttack(int attacker,int target){
        /*몬스터를 공격*/
        enemy[target].Hurt(friendly[attacker].Attack());
        //생존확인
        if(!enemy[target].isLive()){
            window.mobdie(target,enemy[target].getDieimage());
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    public void select_mob (Drawable d){
        //적선택
        for (int i=0;i<enemy.length;i++){
            if(enemy[i].isLive())
                window.select_mob(d,i);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public boolean finish_select_mob(int target){
        if(!enemy[target].isLive())
            return false;
        for (int i=0;i<enemy.length;i++){
            if(enemy[i].isLive())
                window.finish_select_mob(i);
        }
        return true;
    }













}
