package com.rpg.newgame.object.data;

public class Damage {
    public double Physical;
    public double Magic;
    public double trued;

}
