package com.rpg.newgame.object.data;

public class Damage {
    public double Physical;
    public double Magic;
    public double trued;

    public Damage(double phy, double mag, double t){
        Physical=phy;
        Magic=mag;
        trued=t;
    }

    public Damage(double p, double m){
        Physical=p;
        Magic=m;
        trued=0;
    }
}
