package com.rpg.newgame.object;

import com.rpg.newgame.object.data.Damage;

abstract public class Mob extends Entity{

    protected int item;

    @Override
    public void Hurt(Damage damage){ //데미지를 입을때
        HP-=damage.Physical*(100.0/Def);
        HP-=damage.Magic*(100.0/MRt);
        HP-=damage.trued;
        if(HP<=0) {
            HP=0;
            Die();
        }
    }

    @Override
    public void Heal(double heal){
        HP+=heal;
        if(HP>MaxHP)
            HP=MaxHP;
    }
}
