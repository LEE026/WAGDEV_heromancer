package com.rpg.newgame;

import android.content.Context;
import android.widget.Button;
import android.widget.LinearLayout;


public class ChatUI {

    private int buttonNum=4;
    private LinearLayout layout;
    private Context context;
    private clickevent clickevent;

    private Button[] btn=new Button[buttonNum];

    public ChatUI(LinearLayout l, Context con,clickevent clickevent){
        this.layout=l;
        this.context=con;
        this.clickevent=clickevent;
        for (int i=0;i<4;i++){
            btn[i]=new Button(context);
        }

        draw_startmenu();
    }

    String[] s={"공격","스킬","아이템","강제처형"};
    LinearLayout.LayoutParams param= new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.MATCH_PARENT,1);
    public void draw_startmenu(){
        for (int i=0;i<buttonNum;i++){
            btn[i].setText(s[i]);
            btn[i].setLayoutParams(param);
            btn[i].setOnClickListener(clickevent.attack);
            layout.addView(btn[i]);
        }
    }





}
