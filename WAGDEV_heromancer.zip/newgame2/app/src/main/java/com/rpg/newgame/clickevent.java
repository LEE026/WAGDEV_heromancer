package com.rpg.newgame;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;

import androidx.annotation.RequiresApi;

public class clickevent {
    private Resources resources;
    private BattleHandler handler;

    //상태
    private int state=0;
    private boolean mobtarget=false;
    //리스너
    public View.OnClickListener[] startbtn=new View.OnClickListener[4]; //0공격 1스킬 2아이템 3강제처형
    public View.OnClickListener mob;




    public clickevent(Resources r){
        this.resources=r;
    }

    public Resources getResources() {
        return resources;
    }

    public void setMobtarget(boolean mobtarget) {
        this.mobtarget = mobtarget;
    }

    public void setHandler(BattleHandler handler) {
        this.handler = handler;
        init_click();
    }

    private void init_click(){

        //공격 시, 상태 1
        startbtn[0]=new View.OnClickListener() {
            Drawable d=resources.getDrawable(R.color.강제처형);//임시설정
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                if(state!=1) {
                    state = 1;
                    handler.select_mob(d);
                }
            }
        };
        //임시등록
        startbtn[1]=startbtn[0];
        startbtn[2]=startbtn[0];
        startbtn[3]=startbtn[0];


        //mob 이미지버튼에 들어갈 리스너
        mob=new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                if(mobtarget){
                    int target;
                    switch (v.getId()){
                        case R.id.mob1:
                            target=0;
                            break;
                        case R.id.mob2:
                            target=1;
                            break;
                        case R.id.mob3:
                            target=2;
                            break;
                        case R.id.mob4:
                            target=3;
                            break;
                        default:
                            return;
                    }

                    if(!handler.finish_select_mob(target))
                        return;

                    switch (state){
                        case 1:
                            handler.MobAttack(target);
                            break;
                    }
                    state=0;


                }//if끝

            }//함수 끝
        };







    }



}
