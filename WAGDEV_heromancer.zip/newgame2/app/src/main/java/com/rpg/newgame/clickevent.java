package com.rpg.newgame;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;

import androidx.annotation.RequiresApi;

public class clickevent {
    private Resources resources;
    private BattleHandler handler;

    //상태
    int state=0;
    //리스너
    public View.OnClickListener attack;




    public clickevent(Resources r){
        this.resources=r;
    }

    public void setHandler(BattleHandler handler) {
        this.handler = handler;
        init_click();
    }

    private void init_click(){

        //공격 시, 상태 1
        attack=new View.OnClickListener() {
            Drawable d=resources.getDrawable(R.color.강제처형);//임시설정
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                state=1;
                handler.test(d);
            }
        };




    }



}
