package com.rpg.newgame;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;

import androidx.annotation.RequiresApi;

public class clickevent {
    private Resources resources;
    private BattleHandler handler;

    //상태
    private int state=0;
    private boolean mobtarget=false;
    private boolean playertarget=false;
    //리스너
    public View.OnClickListener[] startbtn=new View.OnClickListener[4]; //0공격 1스킬 2아이템 3강제처형
    public View.OnClickListener mob;
    public View.OnClickListener[] skillbtn=new View.OnClickListener[4]; //0공격 1스킬 2아이템 3강제처형
    public View.OnClickListener player;




    public clickevent(Resources r){
        this.resources=r;
    }

    public Resources getResources() {
        return resources;
    }

    public void setMobtarget(boolean mobtarget) {
        this.mobtarget = mobtarget;
    }

    public void setPlayertarget(boolean playertarget) {
        this.playertarget = playertarget;
    }

    public void setHandler(BattleHandler handler) {
        this.handler = handler;
        init_click();
    }

    private void init_click(){

        //시작메뉴
        //공격 시, 상태 1
        startbtn[0]=new View.OnClickListener() {
            Drawable d=resources.getDrawable(R.color.강제처형);//임시설정
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                if(state!=1) {
                    state = 1;
                    handler.select_mob(d);
                }
            }
        };

        startbtn[1]=new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handler.draw_skillmenu();
            }
        };
        //임시등록
        startbtn[2]=startbtn[0];
        startbtn[3]=startbtn[0];

        //스킬메뉴
        skillbtn[0]=startbtn[0];

        skillbtn[1]=new View.OnClickListener() {
            Drawable d=resources.getDrawable(R.color.아군타겟);
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                state=3;
                handler.select_player(d);
            }
        };
        skillbtn[2]=startbtn[0];
        skillbtn[3]=startbtn[0];




        //mob 이미지버튼에 들어갈 리스너
        mob=new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                if(mobtarget){
                    int target;
                    switch (v.getId()){
                        case R.id.mob1:
                            target=0;
                            break;
                        case R.id.mob2:
                            target=1;
                            break;
                        case R.id.mob3:
                            target=2;
                            break;
                        case R.id.mob4:
                            target=3;
                            break;
                        default:
                            return;
                    }

                    if(!handler.finish_select_mob(target))
                        return;

                    switch (state){
                        case 1:
                            handler.MobAttack(target);
                            break;
                    }
                    state=0;


                }//if끝

            }//함수 끝
        };

        //player 이미지버튼에 들어갈 리스너
        player=new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                if(playertarget){
                    int target;
                    switch (v.getId()){
                        case R.id.player1:
                            target=0;
                            break;
                        case R.id.player2:
                            target=1;
                            break;
                        case R.id.player3:
                            target=2;
                            break;
                        case R.id.player4:
                            target=3;
                            break;
                        default:
                            return;
                    }

                    if(!handler.finish_select_player(target))
                        return;

                    switch (state){
                        case 3:
                            handler.PlayerHeal(target);
                            break;
                    }
                    state=0;


                }//if끝

            }//함수 끝
        };









    }



}
