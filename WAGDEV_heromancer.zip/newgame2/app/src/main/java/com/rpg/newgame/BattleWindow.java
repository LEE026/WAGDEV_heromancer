package com.rpg.newgame;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import androidx.annotation.RequiresApi;
import androidx.constraintlayout.widget.ConstraintLayout;

public class BattleWindow {

    private int mobNum;
    private int playerNum;
    private ConstraintLayout layout;
    private Context context;
    private clickevent c;

    public BattleWindow(ConstraintLayout l, Context con, int playerNum, int mobNum,clickevent c){
        this.layout=l;
        this.context=con;
        this.playerNum=playerNum;
        this.mobNum=mobNum;
        this.c=c;


        //layout.findViewById(R.id.mob3).setVisibility(View.INVISIBLE);

    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void test(Drawable d, int i){
        layout.findViewById(R.id.mob1).setForeground(d);
    }
}
